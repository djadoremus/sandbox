getQuestions = function(){
	var questionsText = '['+
		'{"id":1,"question":"__________ refers to humanity in its state of weakness and mortality. ","answer":"Flesh","point":400},' + 
		'{"id":2,"question":"Resurrection of the body means<br/><br/>'+
			'a. The definitive state of man where his spiritual soul is separated from his body<br/>'+
			'b. The definitive state of man where his spiritual soul is not separated from his body<br/>'+
			'c. That mortal bodies will one day come to life again<br/>'+
			'd. Only b and c are correct<br/>'+
		'","answer":"d. only b and c are correct","point":500},'+
		'{"id":3,"question":"Since Jesus Christ truly rose from the dead, he will raise everyone on the last day with an incorruptible body.<br/><br/>'+
			'a. This is false<br/>'+
			'b. This is true<br/>'+
			'c. This is partially true<br/>'+
			'd. None of the above<br/>'+
		'","answer":"b. This is true","point":100},'+
		'{"id":4,"question":"After death, the body and soul are separated.  The body becomes incorruptible while the soul meets the judgment of God.<br/><br/>'+
			'a. This is false<br/>'+
			'b. This is true<br/>'+
			'c. This is partly false<br/>'+
			'd. None of the above<br/>'+
		'","answer":"a. This is false","point":300},'+
		'{"id":5,"question":"Dying in Christ Jesus means to die in the state of God’s ________ without any mortal sin","answer":"Grace","point":200},' + 
		'{"id":6,"question":"_______________ life begins immediately after death.","answer":"Eternal","point":100},' + 
		'{"id":7,"question":"This is the judgment of immediate retribution each receives after death.  This is in accordance with his faith and his works.  It refers to entrance into happiness of heaven, immediate or after an appropriate purification, or entry into eternal damnation.<br/>This refers to <br/><br/>'+
			'a. General Judgement<br/>'+
			'b. Particular Judgement<br/>'+
			'c. Second coming<br/>'+
			'd. None of the above<br/>'+
		'","answer":"b. Particular Judgement","point":200},'+
		'{"id":8,"question":"___________ means the state of supreme and definitive happiness.  They will see God “face to face”.","answer":"Heaven","point":300},' + 
		'{"id":9,"question":"This is the state of those who die in God’s friendship assured of their eternal salvation but needs purification to enter eternal life.","answer":"Purgatory","point":200},' + 
		'{"id":10,"question":" We can help souls in purgatory by offering prayers in suffrage for them, ___________, indulgences and works of penance.","answer":"Almsgiving","point":200},' + 
		'{"id":11,"question":"This refers to eternal damnation of those who die in mortal sin through their own free choice.  It refers to the eternal  _________________ separation from God.","answer":"Separation","point":300},' + 
		'{"id":12,"question":"God created man to be free and respects man’s decision. Man can freely exclude himself from communion with God if at moment of death, he persists in mortal sin and refuses the merciful love of God.<br/><br/>'+
			'a. This is true<br/>'+
			'b. This is false<br/>'+
			'c. This is partially true<br/>'+
			'd. None of the above<br/>'+
		'","answer":"a. This is true","point":300},'+
		'{"id":13,"question":"Final and universal judgment refers to a sentence of ______________ or eternal condemnation.","answer":"Happiness","point":300},' + 
		'{"id":14,"question":"When will final judgment occur?","answer":"At the end of the world","point":400},' + 
		'{"id":15,"question":"After the final judgment, the ______________ will be freed from decay, share in the glory of Christ, fullness of the Kingdom of God will come about.","answer":"Universe","point":400},' + 
		'{"id":16,"question":"Who is the definitive AMEN?","answer":"Christ the Lord","point":400},' + 
		'{"id":17,"question":"What is the celebration of the mystery of Christ in his paschal mystery. ","answer":"Liturgy","point":200},' + 
		'{"id":18,"question":"Liturgy is the sacred action par excellence.  It is the summit where the activity of Church is directed.<br/><br/>'+
			'a. This is false<br/>'+
			'b. This is true<br/>'+
			'c. This is neither true nor false<br/>'+
			'd. None of the above<br/>'+
		'","answer":"b. This is true","point":100},'+
		'{"id":19,"question":"It is the communication of the fruits of Christ’s redemption ","answer":"Sacramental economy","point":400},' + 
		'{"id":20,"question":"Through the liturgy, the ___________ fills us with his blessings in the Word made flesh who died and rose for us and pours into our hearts the Holy Spirit.","answer":"Father","point":400},' + 
		'{"id":21,"question":"In the liturgy, Christ signifies and makes present his paschal mystery <br/><br/>'+
			'a. This is true<br/>'+
			'b. This is false<br/>'+
			'c. This is partially true<br/>'+
			'd. None of the above<br/>'+
		'","answer":"a. This is true","point":100},'+
		'{"id":22,"question":"Through the liturgy, the ____________ prepares the church to encounter her Lord, makes the mystery of Christ present, unites the Church to the life and mission of Christ.","answer":"Holy Spirit","point":300},' + 
		'{"id":23,"question":"What are efficacious signs of grace instituted by Christ and entrusted to the Church.","answer":"Sacraments","point":400},' + 
		'{"id":24,"question":"The mysteries of Christ are the foundation of the sacraments.<br/><br/>'+
			'a. This is true<br/>'+
			'b. This is false<br/>'+
			'c. This is partly false<br/>'+
			'd. None of the above<br/>'+
		'","answer":"a. This is true","point":100},'+
		'{"id":25,"question":"Christ entrusted the sacraments to the Church: they are from her since they are actions of the Church and _________ since this builds the church","answer":"For her","point":400},' + 
	']';
	return JSON.parse(questionsText);
}
